This program is created by Keith Ecker and Andy Achenreiner for CS537 at the University of Wisconsin - Madison. This
program attempts to recreate the make command. It searches the directory for a makefile than checks the targets and it's
dependencies. If the target is out of date it runs any commands that are associated with the given target.